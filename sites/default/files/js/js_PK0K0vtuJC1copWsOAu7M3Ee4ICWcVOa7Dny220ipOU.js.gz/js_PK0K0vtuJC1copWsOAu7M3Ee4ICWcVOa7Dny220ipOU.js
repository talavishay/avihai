Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n!=1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"\u05ea\u05e7\u05dc\u05ea AJAX HTTP \u05e7\u05e8\u05ea\u05d4.","HTTP Result Code: !status":"\u05e7\u05d5\u05d3 \u05ea\u05d5\u05e6\u05d0\u05ea HTTP: !status","An AJAX HTTP request terminated abnormally.":"\u05d1\u05e7\u05e9\u05ea AJAX HTTP \u05d4\u05d5\u05e4\u05e1\u05e7\u05d4 \u05d1\u05d8\u05e8\u05dd \u05e2\u05ea.","Debugging information follows.":"\u05de\u05d9\u05d3\u05e2 \u05dc\u05e0\u05d9\u05e4\u05d5\u05d9 \u05e9\u05d2\u05d9\u05d0\u05d5\u05ea \u05de\u05d5\u05e6\u05d2 \u05dc\u05d4\u05dc\u05df.","Path: !uri":"\u05e0\u05ea\u05d9\u05d1: !uri","StatusText: !statusText":"\u05d8\u05e7\u05e1\u05d8 \u05e1\u05d8\u05d8\u05d5\u05e1: !statusText","ResponseText: !responseText":"\u05d8\u05e7\u05e1\u05d8 \u05ea\u05d2\u05d5\u05d1\u05d4: !responseText","ReadyState: !readyState":"\u05de\u05e6\u05d1 \u05de\u05d5\u05db\u05e0\u05d5\u05ea: !readyState","@title dialog":"\u05d3\u05d9\u05d0\u05dc\u05d5\u05d2 @title","Configure":"\u05d4\u05d2\u05d3\u05e8","Loading":"\u05d8\u05d5\u05e2\u05df","(active tab)":"(\u05dc\u05e9\u05d5\u05e0\u05d9\u05ea \u05e4\u05e2\u05d9\u05dc\u05d4)","Re-order rows by numerical weight instead of dragging.":"\u05e1\u05d3\u05e8 \u05de\u05d7\u05d3\u05e9 \u05e9\u05d5\u05e8\u05d5\u05ea \u05e2\u05e4\u0022\u05d9 \u05d7\u05e9\u05d9\u05d1\u05d5\u05ea \u05de\u05e1\u05e4\u05e8\u05d9\u05ea \u05d1\u05de\u05e7\u05d5\u05dd \u05d2\u05e8\u05d9\u05e8\u05d4.","Show row weights":"\u05d4\u05e6\u05d2 \u05de\u05e9\u05e7\u05dc\u05d9 \u05e9\u05d5\u05e8\u05d5\u05ea","Hide row weights":"\u05d4\u05e1\u05ea\u05e8 \u05de\u05e9\u05e7\u05dc\u05d9 \u05e9\u05d5\u05e8\u05d5\u05ea","Drag to re-order":"\u05d2\u05e8\u05d5\u05e8 \u05dc\u05e1\u05d9\u05d3\u05d5\u05e8","Changes made in this table will not be saved until the form is submitted.":"\u05e9\u05d9\u05e0\u05d5\u05d9\u05d9\u05dd \u05d1\u05d8\u05d1\u05dc\u05d4 \u05d6\u05d5 \u05dc\u05d0 \u05d9\u05e9\u05de\u05e8\u05d5 \u05e2\u05d3 \u05dc\u05e9\u05dc\u05d9\u05d7\u05ea \u05d4\u05d8\u05d5\u05e4\u05e1.","Hide":"\u05d4\u05e1\u05ea\u05e8\u05d4","Show":"\u05d4\u05e6\u05d2","Disabled":"\u05de\u05d5\u05e9\u05d1\u05ea","Enabled":"\u05de\u05d5\u05e4\u05e2\u05dc","Edit":"\u05e2\u05e8\u05d9\u05db\u05d4","Save":"\u05e9\u05de\u05d9\u05e8\u05d4","Add":"\u05d4\u05d5\u05e1\u05e3","Upload":"\u05d4\u05e2\u05dc\u05d0\u05d4","OK":"OK","Select all rows in this table":"\u05d1\u05d7\u05e8 \u05d0\u05ea \u05db\u05dc \u05d4\u05e9\u05d5\u05e8\u05d5\u05ea \u05d1\u05d8\u05d1\u05dc\u05d4","Deselect all rows in this table":"\u05d1\u05d8\u05dc \u05d1\u05d7\u05d9\u05e8\u05ea \u05db\u05dc \u05d4\u05e9\u05d5\u05e8\u05d5\u05ea \u05d1\u05d8\u05d1\u05dc\u05d4","Not published":"\u05d8\u05e8\u05dd \u05e4\u05d5\u05e8\u05e1\u05dd","Please wait...":"\u05d4\u05de\u05ea\u05df \u05d1\u05d1\u05e7\u05e9\u05d4...","Only files with the following extensions are allowed: %files-allowed.":"\u05e0\u05d9\u05ea\u05df \u05dc\u05d4\u05e9\u05ea\u05de\u05e9 \u05e8\u05e7 \u05d1\u05e7\u05d1\u05e6\u05d9\u05dd \u05d1\u05e2\u05dc\u05d9 \u05d4\u05e1\u05d9\u05d5\u05de\u05d5\u05ea \u05d4\u05d1\u05d0\u05d5\u05ea: %files-allowed.","By @name on @date":"\u05e2\u0022\u05d9 @name \u05d1- @date","By @name":"\u05e2\u0022\u05d9 @name","Not in menu":"\u05dc\u05d0 \u05d1\u05ea\u05e4\u05e8\u05d9\u05d8","No alias":"\u05dc\u05d0 \u05d4\u05d5\u05d2\u05d3\u05e8 \u05de\u05d9\u05e7\u05d5\u05dd \u05d7\u05d9\u05dc\u05d5\u05e4\u05d9","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"\u05d4\u05e9\u05d9\u05e0\u05d5\u05d9\u05d9\u05dd \u05dc\u05d1\u05dc\u05d5\u05e7\u05d9\u05dd \u05d0\u05dc\u05d5 \u05dc\u05d0 \u05d9\u05e9\u05de\u05e8\u05d5 \u05e2\u05d3 \u05dc\u05dc\u05d7\u05d9\u05e6\u05d4 \u05e2\u05dc \u05db\u05e4\u05ea\u05d5\u05e8 \u003Cem\u003E\u05e9\u05de\u05d5\u05e8 \u05d1\u05dc\u05d5\u05e7\u05d9\u05dd\u003C\/em\u003E.","Flag translations as outdated":"\u05e1\u05de\u05df \u05ea\u05e8\u05d2\u05d5\u05de\u05d9\u05dd \u05db\u05dc\u05d0 \u05de\u05e2\u05d5\u05d3\u05db\u05e0\u05d9\u05dd","No revision":"\u05d0\u05d9\u05df \u05d2\u05d9\u05e8\u05e1\u05d4","Requires a title":"\u05d3\u05e8\u05d5\u05e9\u05d4 \u05db\u05d5\u05ea\u05e8\u05ea","Not restricted":"\u05dc\u05d0 \u05de\u05d5\u05d2\u05d1\u05dc","Not customizable":"\u05d0\u05d9\u05e0\u05d5 \u05e0\u05d9\u05ea\u05df \u05dc\u05d4\u05ea\u05d0\u05de\u05d4 \u05d0\u05d9\u05e9\u05d9\u05ea","Restricted to certain pages":"\u05de\u05d5\u05d2\u05d1\u05dc \u05dc\u05d3\u05e4\u05d9\u05dd \u05de\u05e1\u05d5\u05d9\u05d9\u05de\u05d9\u05dd","The block cannot be placed in this region.":"\u05dc\u05d0 \u05e0\u05d9\u05ea\u05df \u05dc\u05de\u05e7\u05dd \u05d0\u05ea \u05d4\u05ea\u05d9\u05d1\u05d4 \u05d1\u05d0\u05d9\u05d6\u05d5\u05e8 \u05d6\u05d4","Hide summary":"\u05d4\u05e1\u05ea\u05e8\u05ea \u05ea\u05e7\u05e6\u05d9\u05e8","Edit summary":"\u05e2\u05e8\u05d9\u05db\u05ea \u05ea\u05e7\u05e6\u05d9\u05e8","Don\u0027t display post information":"\u05dc\u05d0 \u05dc\u05d4\u05e6\u05d9\u05d2 \u05de\u05d9\u05d3\u05e2 \u05e2\u05dc \u05d4\u05e4\u05d5\u05e1\u05d8","Autocomplete popup":"\u05d7\u05dc\u05d5\u05df \u05d4\u05e9\u05dc\u05de\u05d4 \u05d0\u05d5\u05d8\u05d5\u05de\u05d8\u05d9\u05ea \u05e7\u05d5\u05e4\u05e5","Searching for matches...":"\u05de\u05d7\u05e4\u05e9 \u05e2\u05d1\u05d5\u05e8 \u05ea\u05d0\u05d9\u05de\u05d5\u05d9\u05d5\u05ea...","Not translatable":"\u05dc\u05d0 \u05e0\u05d9\u05ea\u05df \u05dc\u05ea\u05e8\u05d2\u05d5\u05dd"}} };;
(function () {
Drupal.behaviors.avihai = {
	attach: function (context, settings) {
		var menu_target = null,title = jQuery("#edit-title-field input");
		
			if(jQuery("form.node-form [name=changed]").val() !== ""){
				title.attr("data-original-title", function(v,a){return this.value});
				jQuery("#multiple-node-menu-wrapper input.form-text").each(function(i, val){
					if(jQuery(val).val() === title.attr("data-original-title") ){
						jQuery(val).attr("data-target",1);
						menu_target = val;
					}
				});
			}
			title.bind("change blur keyup", function(e){
				if(window.location.toString().match(/edit/) === null || window.location.toString().match(/edit(.*)add/) !== null){
					jQuery("#edit-menu-link-title,#edit-multiple-node-menu-add-link-link-title").val(jQuery(e.currentTarget).val());
				}else{
					jQuery(menu_target).val(jQuery(e.currentTarget).val());
				}
			});
			
			jQuery("#edit-multiple-node-menu-enabled:not(:checked)").click();
			
			jQuery(".language-link[lang=en]").attr("href", function(a, b){
				return b.replace(/%D7%94%D7%90%D7%A0%D7%A9%D7%99%D7%9D/,"people");
			});
			jQuery(".language-link[lang=he]").attr("href", function(a, b){
				return b.replace(/people/,"האנשים");
			});
	}
}
})();

jQuery(document).ready(function () { 
	Drupal.behaviors.avihai.attach();
	var t1 = window.setTimeout(function(){
		if(jQuery("body").hasClass("admin-menu")){		
			jQuery("#admin-menu [href*=\\/block\\/add]").attr("href",'/'+Drupal.settings.pathPrefix+"node/add/media-block"); 
		}
	},1000);
});
;
(function() {
  var $;

  $ = jQuery;

  $.widget("ui.dialogExtend", {
    version: "2.0.0",
    modes: {},
    options: {
      "closable": true,
      "dblclick": false,
      "titlebar": false,
      "icons": {
        "close": "ui-icon-closethick",
        "restore": "ui-icon-newwin"
      },
      "load": null,
      "beforeRestore": null,
      "restore": null
    },
    _create: function() {
      this._state = "normal";
      if (!$(this.element[0]).data("ui-dialog")) {
        $.error("jQuery.dialogExtend Error : Only jQuery UI Dialog element is accepted");
      }
      this._verifyOptions();
      this._initStyles();
      this._initButtons();
      this._initTitleBar();
      this._setState("normal");
      this._on("load", function(e) {
        return console.log("test", e);
      });
      return this._trigger("load");
    },
    _setState: function(state) {
      $(this.element[0]).removeClass("ui-dialog-" + this._state).addClass("ui-dialog-" + state);
      return this._state = state;
    },
    _verifyOptions: function() {
      var name, _ref, _results;

      if (this.options.dblclick && !(this.options.dblclick in this.modes)) {
        $.error("jQuery.dialogExtend Error : Invalid <dblclick> value '" + this.options.dblclick + "'");
        this.options.dblclick = false;
      }
      if (this.options.titlebar && ((_ref = this.options.titlebar) !== "none" && _ref !== "transparent")) {
        $.error("jQuery.dialogExtend Error : Invalid <titlebar> value '" + this.options.titlebar + "'");
        this.options.titlebar = false;
      }
      _results = [];
      for (name in this.modes) {
        if (this["_verifyOptions_" + name]) {
          _results.push(this["_verifyOptions_" + name]());
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    },
    _initStyles: function() {
      var name, style, _results;

      if (!$(".dialog-extend-css").length) {
        style = '';
        style += '<style class="dialog-extend-css" type="text/css">';
        style += '.ui-dialog .ui-dialog-titlebar-buttonpane>a { float: right; }';
        style += '.ui-dialog .ui-dialog-titlebar-restore { width: 19px; height: 18px; }';
        style += '.ui-dialog .ui-dialog-titlebar-restore span { display: block; margin: 1px; }';
        style += '.ui-dialog .ui-dialog-titlebar-restore:hover,';
        style += '.ui-dialog .ui-dialog-titlebar-restore:focus { padding: 0; }';
        style += '.ui-dialog .ui-dialog-titlebar ::selection { background-color: transparent; }';
        style += '</style>';
        $(style).appendTo("body");
      }
      _results = [];
      for (name in this.modes) {
        _results.push(this["_initStyles_" + name]());
      }
      return _results;
    },
    _initButtons: function() {
      var buttonPane, mode, name, titlebar, _ref,
        _this = this;

      titlebar = $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar");
      buttonPane = $('<div class="ui-dialog-titlebar-buttonpane"></div>').appendTo(titlebar);
      buttonPane.css({
        "position": "absolute",
        "top": "50%",
        "right": "0.3em",
        "margin-top": "-10px",
        "height": "18px"
      });
      titlebar.find(".ui-dialog-titlebar-close").css({
        "position": "relative",
        "float": "right",
        "top": "auto",
        "right": "auto",
        "margin": 0
      }).find(".ui-icon").removeClass("ui-icon-closethick").addClass(this.options.icons.close).end().appendTo(buttonPane).end();
      buttonPane.append('<a class="ui-dialog-titlebar-restore ui-corner-all ui-state-default" href="#"><span class="ui-icon ' + this.options.icons.restore + '">restore</span></a>').find('.ui-dialog-titlebar-restore').attr("role", "button").mouseover(function() {
        return $(this).addClass("ui-state-hover");
      }).mouseout(function() {
        return $(this).removeClass("ui-state-hover");
      }).focus(function() {
        return $(this).addClass("ui-state-focus");
      }).blur(function() {
        return $(this).removeClass("ui-state-focus");
      }).end().find(".ui-dialog-titlebar-close").toggle(this.options.closable).end().find(".ui-dialog-titlebar-restore").hide().click(function(e) {
        e.preventDefault();
        return _this.restore();
      }).end();
      _ref = this.modes;
      for (name in _ref) {
        mode = _ref[name];
        this._initModuleButton(name, mode);
      }
      return titlebar.dblclick(function(evt) {
        if (_this.options.dblclick) {
          if (_this._state !== "normal") {
            return _this.restore();
          } else {
            return _this[_this.options.dblclick]();
          }
        }
      }).select(function() {
        return false;
      });
    },
    _initModuleButton: function(name, mode) {
      var buttonPane,
        _this = this;

      buttonPane = $(this.element[0]).dialog("widget").find('.ui-dialog-titlebar-buttonpane');
      return buttonPane.append('<a class="ui-dialog-titlebar-' + name + ' ui-corner-all ui-state-default" href="#"><span class="ui-icon ' + this.options.icons[name] + '">' + name + '</span></a>').find(".ui-dialog-titlebar-" + name).attr("role", "button").mouseover(function() {
        return $(this).addClass("ui-state-hover");
      }).mouseout(function() {
        return $(this).removeClass("ui-state-hover");
      }).focus(function() {
        return $(this).addClass("ui-state-focus");
      }).blur(function() {
        return $(this).removeClass("ui-state-focus");
      }).end().find(".ui-dialog-titlebar-" + name).toggle(this.options[mode.option]).click(function(e) {
        e.preventDefault();
        return _this[name]();
      }).end();
    },
    _initTitleBar: function() {
      var handle;

      switch (this.options.titlebar) {
        case false:
          return 0;
        case "none":
          if ($(this.element[0]).dialog("option", "draggable")) {
            handle = $("<div />").addClass("ui-dialog-draggable-handle").css("cursor", "move").height(5);
            $(this.element[0]).dialog("widget").prepend(handle).draggable("option", "handle", handle);
          }
          return $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar").find(".ui-dialog-title").html("&nbsp;").end().css({
            "background-color": "transparent",
            "background-image": "none",
            "border": 0,
            "position": "absolute",
            "right": 0,
            "top": 0,
            "z-index": 9999
          }).end();
        case "transparent":
          return $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar").css({
            "background-color": "transparent",
            "background-image": "none",
            "border": 0
          });
        default:
          return $.error("jQuery.dialogExtend Error : Invalid <titlebar> value '" + this.options.titlebar + "'");
      }
    },
    state: function() {
      return this._state;
    },
    restore: function() {
      this._trigger("beforeRestore");
      this._restore();
      this._setState("normal");
      this._toggleButtons();
      return this._trigger("restore");
    },
    _restore: function() {
      if (this._state !== "normal") {
        return this["_restore_" + this._state]();
      }
    },
    _saveSnapshot: function() {
      if (this._state === "normal") {
        this.original_config_resizable = $(this.element[0]).dialog("option", "resizable");
        this.original_config_draggable = $(this.element[0]).dialog("option", "draggable");
        this.original_size_height = $(this.element[0]).dialog("widget").outerHeight();
        this.original_size_width = $(this.element[0]).dialog("option", "width");
        this.original_size_maxHeight = $(this.element[0]).dialog("option", "maxHeight");
        this.original_position_mode = $(this.element[0]).dialog("widget").css("position");
        this.original_position_left = $(this.element[0]).dialog("widget").offset().left - $('body').scrollLeft();
        this.original_position_top = $(this.element[0]).dialog("widget").offset().top - $('body').scrollTop();
        return this.original_titlebar_wrap = $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar").css("white-space");
      }
    },
    _loadSnapshot: function() {
      return {
        "config": {
          "resizable": this.original_config_resizable,
          "draggable": this.original_config_draggable
        },
        "size": {
          "height": this.original_size_height,
          "width": this.original_size_width,
          "maxHeight": this.original_size_maxHeight
        },
        "position": {
          "mode": this.original_position_mode,
          "left": this.original_position_left,
          "top": this.original_position_top
        },
        "titlebar": {
          "wrap": this.original_titlebar_wrap
        }
      };
    },
    _toggleButtons: function() {
      var mode, name, _ref, _ref1, _results;

      $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar-restore").toggle(this._state !== "normal").css({
        "right": "1.4em"
      }).end();
      _ref = this.modes;
      for (name in _ref) {
        mode = _ref[name];
        $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar-" + name).toggle(this._state !== mode.state && this.options[mode.option]);
      }
      _ref1 = this.modes;
      _results = [];
      for (name in _ref1) {
        mode = _ref1[name];
        if (mode.state === this._state) {
          _results.push($(this.element[0]).dialog("widget").find(".ui-dialog-titlebar-restore").insertAfter($(this.element[0]).dialog("widget").find(".ui-dialog-titlebar-" + name)).end());
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    }
  });

}).call(this);

(function() {
  var $;

  $ = jQuery;

  $.extend(true, $.ui.dialogExtend.prototype, {
    modes: {
      "collapse": {
        option: "collapsable",
        state: "collapsed"
      }
    },
    options: {
      "collapsable": false,
      "icons": {
        "collapse": "ui-icon-triangle-1-s"
      },
      "beforeCollapse": null,
      "collapse": null
    },
    collapse: function() {
      var newHeight;

      newHeight = $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar").height() + 15;
      this._trigger("beforeCollapse");
      if (this._state !== "normal") {
        this._restore();
      }
      this._saveSnapshot();
      $(this.element[0]).dialog("option", {
        "resizable": false,
        "height": newHeight,
        "maxHeight": newHeight
      }).on('dialogclose', this._collapse_restore).hide().dialog("widget").find(".ui-dialog-buttonpane:visible").hide().end().find(".ui-dialog-titlebar").css("white-space", "nowrap").end().find(".ui-dialog-content");
      this._setState("collapsed");
      this._toggleButtons();
      return this._trigger("collapse");
    },
    _restore_collapsed: function() {
      var original;

      original = this._loadSnapshot();
      return $(this.element[0]).show().dialog("widget").find(".ui-dialog-buttonpane:hidden").show().end().find(".ui-dialog-titlebar").css("white-space", original.titlebar.wrap).end().find(".ui-dialog-content").dialog("option", {
        "resizable": original.config.resizable,
        "height": original.size.height,
        "maxHeight": original.size.maxHeight
      }).off('dialogclose', this._collapse_restore);
    },
    _initStyles_collapse: function() {
      var style;

      if (!$(".dialog-extend-collapse-css").length) {
        style = '';
        style += '<style class="dialog-extend-collapse-css" type="text/css">';
        style += '.ui-dialog .ui-dialog-titlebar-collapse { width: 19px; height: 18px; }';
        style += '.ui-dialog .ui-dialog-titlebar-collapse span { display: block; margin: 1px; }';
        style += '.ui-dialog .ui-dialog-titlebar-collapse:hover,';
        style += '.ui-dialog .ui-dialog-titlebar-collapse:focus { padding: 0; }';
        style += '</style>';
        return $(style).appendTo("body");
      }
    },
    _collapse_restore: function() {
      return $(this).dialogExtend("restore");
    }
  });

}).call(this);

(function() {
  var $;

  $ = jQuery;

  $.extend(true, $.ui.dialogExtend.prototype, {
    modes: {
      "maximize": {
        option: "maximizable",
        state: "maximized"
      }
    },
    options: {
      "maximizable": false,
      "icons": {
        "maximize": "ui-icon-extlink"
      },
      "beforeMaximize": null,
      "maximize": null
    },
    maximize: function() {
      var newHeight, newWidth;

      newHeight = $(window).height() - 11;
      newWidth = $(window).width() - 11;
      this._trigger("beforeMaximize");
      if (this._state !== "normal") {
        this._restore();
      }
      this._saveSnapshot();
      if ($(this.element[0]).dialog("option", "draggable")) {
        $(this.element[0]).dialog("widget").draggable("option", "handle", null).find(".ui-dialog-draggable-handle").css("cursor", "text").end();
      }
      $(this.element[0]).dialog("widget").css("position", "fixed").find(".ui-dialog-content").show().dialog("widget").find(".ui-dialog-buttonpane").show().end().find(".ui-dialog-content").dialog("option", {
        "resizable": false,
        "draggable": false,
        "height": newHeight,
        "width": newWidth,
        "position": {
          my: "left top",
          at: "left top"
        }
      });
      this._setState("maximized");
      this._toggleButtons();
      return this._trigger("maximize");
    },
    _restore_maximized: function() {
      var original;

      original = this._loadSnapshot();
      $(this.element[0]).dialog("widget").css("position", original.position.mode).find(".ui-dialog-titlebar").css("white-space", original.titlebar.wrap).end().find(".ui-dialog-content").dialog("option", {
        "resizable": original.config.resizable,
        "draggable": original.config.draggable,
        "height": original.size.height,
        "width": original.size.width,
        "maxHeight": original.size.maxHeight,
        "position": {
          my: "left top",
          at: "left+" + original.position.left + " top+" + original.position.top
        }
      });
      if ($(this.element[0]).dialog("option", "draggable")) {
        return $(this.element[0]).dialog("widget").draggable("option", "handle", $(this.element[0]).dialog("widget").find(".ui-dialog-draggable-handle").length ? $(this.element[0]).dialog("widget").find(".ui-dialog-draggable-handle") : ".ui-dialog-titlebar").find(".ui-dialog-draggable-handle").css("cursor", "move");
      }
    },
    _initStyles_maximize: function() {
      var style;

      if (!$(".dialog-extend-maximize-css").length) {
        style = '';
        style += '<style class="dialog-extend-maximize-css" type="text/css">';
        style += '.ui-dialog .ui-dialog-titlebar-maximize { width: 19px; height: 18px; }';
        style += '.ui-dialog .ui-dialog-titlebar-maximize span { display: block; margin: 1px; }';
        style += '.ui-dialog .ui-dialog-titlebar-maximize:hover,';
        style += '.ui-dialog .ui-dialog-titlebar-maximize:focus { padding: 0; }';
        style += '</style>';
        return $(style).appendTo("body");
      }
    }
  });

}).call(this);

(function() {
  var $;

  $ = jQuery;

  $.extend(true, $.ui.dialogExtend.prototype, {
    modes: {
      "minimize": {
        option: "minimizable",
        state: "minimized"
      }
    },
    options: {
      "minimizable": false,
      "minimizeLocation": "left",
      "icons": {
        "minimize": "ui-icon-minus"
      },
      "beforeMinimize": null,
      "minimize": null
    },
    minimize: function() {
      var fixedContainer, newHeight, newWidth, overlay;

      newHeight = $(this.element[0]).dialog("widget").find(".ui-dialog-titlebar").height() + 15;
      newWidth = 200;
      if ($("#dialog-extend-fixed-container").length) {
        fixedContainer = $("#dialog-extend-fixed-container");
      } else {
        fixedContainer = $('<div id="dialog-extend-fixed-container"></div>').appendTo("body");
      }
      fixedContainer.css({
        "position": "fixed",
        "bottom": 1,
        "left": 1,
        "right": 1,
        "z-index": 9999
      });
      overlay = $('<div/>').css({
        "float": this.options.minimizeLocation,
        "margin": 1
      });
      fixedContainer.append(overlay);
      $(this.element[0]).data("dialog-extend-minimize-overlay", overlay);
      this._trigger("beforeMinimize");
      this._saveSnapshot();
      if ($(this.element[0]).dialog("option", "draggable")) {
        $(this.element[0]).dialog("widget").draggable("option", "handle", null).find(".ui-dialog-draggable-handle").css("cursor", "text").end();
      }
      $(this.element[0]).dialog("option", {
        "resizable": false,
        "draggable": false,
        "height": newHeight,
        "width": newWidth
      }).on('dialogclose', this._minimize_removeOverlay).dialog("widget").css("position", "static").appendTo(overlay).find(".ui-dialog-content").dialog("widget").find(".ui-dialog-titlebar").each(function() {
        var buttonPane, titleText, titlebar;

        titlebar = $(this);
        buttonPane = titlebar.find(".ui-dialog-titlebar-buttonpane");
        titleText = titlebar.find(".ui-dialog-title");
        return titleText.css({
          'overflow': 'hidden',
          'width': titlebar.width() - buttonPane.width() + 10
        });
      }).end().find(".ui-dialog-content").hide().dialog("widget").find(".ui-dialog-buttonpane:visible").hide().end().find(".ui-dialog-titlebar").css("white-space", "nowrap").end().find(".ui-dialog-content");
      this._setState("minimized");
      this._toggleButtons();
      return this._trigger("minimize");
    },
    _restore_minimized: function() {
      var original;

      original = this._loadSnapshot();
      $(this.element[0]).dialog("widget").appendTo("body").css({
        "float": "none",
        "margin": 0,
        "position": original.position.mode
      }).find(".ui-dialog-content").dialog("widget").find(".ui-dialog-title").css("width", "auto").end().find(".ui-dialog-content").show().dialog("widget").find(".ui-dialog-buttonpane:hidden").show().end().find(".ui-dialog-titlebar").css("white-space", original.titlebar.wrap).end().find(".ui-dialog-content").dialog("option", {
        "resizable": original.config.resizable,
        "draggable": original.config.draggable,
        "height": original.size.height,
        "width": original.size.width,
        "maxHeight": original.size.maxHeight,
        "position": {
          my: "left top",
          at: "left+" + original.position.left + " top+" + original.position.top
        }
      }).off('dialogclose', this._minimize_removeOverlay);
      if ($(this.element[0]).dialog("option", "draggable")) {
        $(this.element[0]).dialog("widget").draggable("option", "handle", $(this.element[0]).dialog("widget").find(".ui-dialog-draggable-handle").length ? $(this.element[0]).dialog("widget").find(".ui-dialog-draggable-handle") : ".ui-dialog-titlebar").find(".ui-dialog-draggable-handle").css("cursor", "move");
      }
      $(this.element[0]).data("dialog-extend-minimize-overlay").remove();
      return $(this.element[0]).removeData("dialog-extend-overlay");
    },
    _initStyles_minimize: function() {
      var style;

      if (!$(".dialog-extend-minimize-css").length) {
        style = '';
        style += '<style class="dialog-extend-minimize-css" type="text/css">';
        style += '.ui-dialog .ui-dialog-titlebar-minimize { width: 19px; height: 18px; }';
        style += '.ui-dialog .ui-dialog-titlebar-minimize span { display: block; margin: 1px; }';
        style += '.ui-dialog .ui-dialog-titlebar-minimize:hover,';
        style += '.ui-dialog .ui-dialog-titlebar-minimize:focus { padding: 0; }';
        style += '</style>';
        return $(style).appendTo("body");
      }
    },
    _verifyOptions_minimize: function() {
      var _ref;

      if (!this.options.minimizeLocation || ((_ref = this.options.minimizeLocation) !== 'left' && _ref !== 'right')) {
        $.error("jQuery.dialogExtend Error : Invalid <minimizeLocation> value '" + this.options.minimizeLocation + "'");
        return this.options.minimizeLocation = "left";
      }
    },
    _minimize_removeOverlay: function() {
      $(this).dialogExtend("restore");
      $(this).dialog("widget").appendTo($('body'));
      $(this).data("dialog-extend-minimize-overlay").remove();
      return $(this).removeData("dialog-extend-overlay");
    }
  });

}).call(this);
;
(function (jQuery) {
Drupal.behaviors.help_dialog = {
	attach: function (context, settings) {
		jQuery("a[data-help]").once().on("click",function(e){
			e.preventDefault();			
			var title = jQuery(e.currentTarget).text();
			var data_help = jQuery(e.currentTarget).attr("data-help");
			/* here you can specify the url */
			var url = '/sites/all/modules/help_dialog/docs/'+data_help;		 
			/* show the image loader */
			//jQuery('#imgLoader').show();			 
			jQuery.ajax({
				url: url,
				success: function( data ) {
					jQuery("<div></div>").html(data).dialog({
						title: title,
						width: '80%',
						height: 400,
					}).dialog('open').dialogExtend({
						"dblclick" : "maximize",
						"icons" : { "maximize" : "ui-icon-arrow-4-diag" },
						"minimizable" : true,
						"maximizable" : true,
						"maximize" : 	function(evt, dlg){ 
											jQuery(this).parent(".ui-dialog").css("top","50px") ;
										},
						"load" : function(evt, dlg){ 
											Drupal.behaviors.help_dialog.attach();
										},
					});
		//          jQuery('#imgLoader').hide();            /* hide the image loader */
				}
			});
			return false;
		});

	}
};
})(jQuery);
;
(function ($) {

/**
 * Attach the machine-readable name form element behavior.
 */
Drupal.behaviors.machineName = {
  /**
   * Attaches the behavior.
   *
   * @param settings.machineName
   *   A list of elements to process, keyed by the HTML ID of the form element
   *   containing the human-readable value. Each element is an object defining
   *   the following properties:
   *   - target: The HTML ID of the machine name form element.
   *   - suffix: The HTML ID of a container to show the machine name preview in
   *     (usually a field suffix after the human-readable name form element).
   *   - label: The label to show for the machine name preview.
   *   - replace_pattern: A regular expression (without modifiers) matching
   *     disallowed characters in the machine name; e.g., '[^a-z0-9]+'.
   *   - replace: A character to replace disallowed characters with; e.g., '_'
   *     or '-'.
   *   - standalone: Whether the preview should stay in its own element rather
   *     than the suffix of the source element.
   *   - field_prefix: The #field_prefix of the form element.
   *   - field_suffix: The #field_suffix of the form element.
   */
  attach: function (context, settings) {
    var self = this;
    $.each(settings.machineName, function (source_id, options) {
      var $source = $(source_id, context).addClass('machine-name-source');
      var $target = $(options.target, context).addClass('machine-name-target');
      var $suffix = $(options.suffix, context);
      var $wrapper = $target.closest('.form-item');
      // All elements have to exist.
      if (!$source.length || !$target.length || !$suffix.length || !$wrapper.length) {
        return;
      }
      // Skip processing upon a form validation error on the machine name.
      if ($target.hasClass('error')) {
        return;
      }
      // Figure out the maximum length for the machine name.
      options.maxlength = $target.attr('maxlength');
      // Hide the form item container of the machine name form element.
      $wrapper.hide();
      // Determine the initial machine name value. Unless the machine name form
      // element is disabled or not empty, the initial default value is based on
      // the human-readable form element value.
      if ($target.is(':disabled') || $target.val() != '') {
        var machine = $target.val();
      }
      else {
        var machine = self.transliterate($source.val(), options);
      }
      // Append the machine name preview to the source field.
      var $preview = $('<span class="machine-name-value">' + options.field_prefix + Drupal.checkPlain(machine) + options.field_suffix + '</span>');
      $suffix.empty();
      if (options.label) {
        $suffix.append(' ').append('<span class="machine-name-label">' + options.label + ':</span>');
      }
      $suffix.append(' ').append($preview);

      // If the machine name cannot be edited, stop further processing.
      if ($target.is(':disabled')) {
        return;
      }

      // If it is editable, append an edit link.
      var $link = $('<span class="admin-link"><a href="#">' + Drupal.t('Edit') + '</a></span>')
        .click(function () {
          $wrapper.show();
          $target.focus();
          $suffix.hide();
          $source.unbind('.machineName');
          return false;
        });
      $suffix.append(' ').append($link);

      // Preview the machine name in realtime when the human-readable name
      // changes, but only if there is no machine name yet; i.e., only upon
      // initial creation, not when editing.
      if ($target.val() == '') {
        $source.bind('keyup.machineName change.machineName input.machineName', function () {
          machine = self.transliterate($(this).val(), options);
          // Set the machine name to the transliterated value.
          if (machine != '') {
            if (machine != options.replace) {
              $target.val(machine);
              $preview.html(options.field_prefix + Drupal.checkPlain(machine) + options.field_suffix);
            }
            $suffix.show();
          }
          else {
            $suffix.hide();
            $target.val(machine);
            $preview.empty();
          }
        });
        // Initialize machine name preview.
        $source.keyup();
      }
    });
  },

  /**
   * Transliterate a human-readable name to a machine name.
   *
   * @param source
   *   A string to transliterate.
   * @param settings
   *   The machine name settings for the corresponding field, containing:
   *   - replace_pattern: A regular expression (without modifiers) matching
   *     disallowed characters in the machine name; e.g., '[^a-z0-9]+'.
   *   - replace: A character to replace disallowed characters with; e.g., '_'
   *     or '-'.
   *   - maxlength: The maximum length of the machine name.
   *
   * @return
   *   The transliterated source string.
   */
  transliterate: function (source, settings) {
    var rx = new RegExp(settings.replace_pattern, 'g');
    return source.toLowerCase().replace(rx, settings.replace).substr(0, settings.maxlength);
  }
};

})(jQuery);
;
(function ($) {

Drupal.behaviors.textarea = {
  attach: function (context, settings) {
    $('.form-textarea-wrapper.resizable', context).once('textarea', function () {
      var staticOffset = null;
      var textarea = $(this).addClass('resizable-textarea').find('textarea');
      var grippie = $('<div class="grippie"></div>').mousedown(startDrag);

      grippie.insertAfter(textarea);

      function startDrag(e) {
        staticOffset = textarea.height() - e.pageY;
        textarea.css('opacity', 0.25);
        $(document).mousemove(performDrag).mouseup(endDrag);
        return false;
      }

      function performDrag(e) {
        textarea.height(Math.max(32, staticOffset + e.pageY) + 'px');
        return false;
      }

      function endDrag(e) {
        $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);
        textarea.css('opacity', 1);
      }
    });
  }
};

})(jQuery);
;
(function ($) {

/**
 * Toggle the visibility of a fieldset using smooth animations.
 */
Drupal.toggleFieldset = function (fieldset) {
  var $fieldset = $(fieldset);
  if ($fieldset.is('.collapsed')) {
    var $content = $('> .fieldset-wrapper', fieldset).hide();
    $fieldset
      .removeClass('collapsed')
      .trigger({ type: 'collapsed', value: false })
      .find('> legend span.fieldset-legend-prefix').html(Drupal.t('Hide'));
    $content.slideDown({
      duration: 'fast',
      easing: 'linear',
      complete: function () {
        Drupal.collapseScrollIntoView(fieldset);
        fieldset.animating = false;
      },
      step: function () {
        // Scroll the fieldset into view.
        Drupal.collapseScrollIntoView(fieldset);
      }
    });
  }
  else {
    $fieldset.trigger({ type: 'collapsed', value: true });
    $('> .fieldset-wrapper', fieldset).slideUp('fast', function () {
      $fieldset
        .addClass('collapsed')
        .find('> legend span.fieldset-legend-prefix').html(Drupal.t('Show'));
      fieldset.animating = false;
    });
  }
};

/**
 * Scroll a given fieldset into view as much as possible.
 */
Drupal.collapseScrollIntoView = function (node) {
  var h = document.documentElement.clientHeight || document.body.clientHeight || 0;
  var offset = document.documentElement.scrollTop || document.body.scrollTop || 0;
  var posY = $(node).offset().top;
  var fudge = 55;
  if (posY + node.offsetHeight + fudge > h + offset) {
    if (node.offsetHeight > h) {
      window.scrollTo(0, posY);
    }
    else {
      window.scrollTo(0, posY + node.offsetHeight - h + fudge);
    }
  }
};

Drupal.behaviors.collapse = {
  attach: function (context, settings) {
    $('fieldset.collapsible', context).once('collapse', function () {
      var $fieldset = $(this);
      // Expand fieldset if there are errors inside, or if it contains an
      // element that is targeted by the URI fragment identifier.
      var anchor = location.hash && location.hash != '#' ? ', ' + location.hash : '';
      if ($fieldset.find('.error' + anchor).length) {
        $fieldset.removeClass('collapsed');
      }

      var summary = $('<span class="summary"></span>');
      $fieldset.
        bind('summaryUpdated', function () {
          var text = $.trim($fieldset.drupalGetSummary());
          summary.html(text ? ' (' + text + ')' : '');
        })
        .trigger('summaryUpdated');

      // Turn the legend into a clickable link, but retain span.fieldset-legend
      // for CSS positioning.
      var $legend = $('> legend .fieldset-legend', this);

      $('<span class="fieldset-legend-prefix element-invisible"></span>')
        .append($fieldset.hasClass('collapsed') ? Drupal.t('Show') : Drupal.t('Hide'))
        .prependTo($legend)
        .after(' ');

      // .wrapInner() does not retain bound events.
      var $link = $('<a class="fieldset-title" href="#"></a>')
        .prepend($legend.contents())
        .appendTo($legend)
        .click(function () {
          var fieldset = $fieldset.get(0);
          // Don't animate multiple times.
          if (!fieldset.animating) {
            fieldset.animating = true;
            Drupal.toggleFieldset(fieldset);
          }
          return false;
        });

      $legend.append(summary);
    });
  }
};

})(jQuery);
;
(function ($) {

Drupal.behaviors.menuChangeParentItems = {
  attach: function (context, settings) {
    $('fieldset#edit-menu input').each(function () {
      $(this).change(function () {
        // Update list of available parent menu items.
        Drupal.menu_update_parent_list();
      });
    });
  }
};

/**
 * Function to set the options of the menu parent item dropdown.
 */
Drupal.menu_update_parent_list = function () {
  var values = [];

  $('input:checked', $('fieldset#edit-menu')).each(function () {
    // Get the names of all checked menus.
    values.push(Drupal.checkPlain($.trim($(this).val())));
  });

  var url = Drupal.settings.basePath + 'admin/structure/menu/parents';
  $.ajax({
    url: location.protocol + '//' + location.host + url,
    type: 'POST',
    data: {'menus[]' : values},
    dataType: 'json',
    success: function (options) {
      // Save key of last selected element.
      var selected = $('fieldset#edit-menu #edit-menu-parent :selected').val();
      // Remove all exisiting options from dropdown.
      $('fieldset#edit-menu #edit-menu-parent').children().remove();
      // Add new options to dropdown.
      jQuery.each(options, function(index, value) {
        $('fieldset#edit-menu #edit-menu-parent').append(
          $('<option ' + (index == selected ? ' selected="selected"' : '') + '></option>').val(index).text(value)
        );
      });
    }
  });
};

})(jQuery);
;
(function ($) {

/**
 * Update the summary for nodeblock's vertical tab.
 */
Drupal.behaviors.nodeblock_fieldsetSummary = {
  attach: function (context) {
    // Use the fieldset id attribute to identify the vertical tab element.
    $('fieldset#edit-nodeblock-settings', context).drupalSetSummary(function (context) {
      return $('input[name=nodeblock]:checked + label').text();
    });
  }
};
})(jQuery);
;
(function ($) {

Drupal.behaviors.contentTypes = {
  attach: function (context) {
    // Provide the vertical tab summaries.
    $('fieldset#edit-submission', context).drupalSetSummary(function(context) {
      var vals = [];
      vals.push(Drupal.checkPlain($('#edit-title-label', context).val()) || Drupal.t('Requires a title'));
      return vals.join(', ');
    });
    $('fieldset#edit-workflow', context).drupalSetSummary(function(context) {
      var vals = [];
      $("input[name^='node_options']:checked", context).parent().each(function() {
        vals.push(Drupal.checkPlain($(this).text()));
      });
      if (!$('#edit-node-options-status', context).is(':checked')) {
        vals.unshift(Drupal.t('Not published'));
      }
      return vals.join(', ');
    });
    $('fieldset#edit-display', context).drupalSetSummary(function(context) {
      var vals = [];
      $('input:checked', context).next('label').each(function() {
        vals.push(Drupal.checkPlain($(this).text()));
      });
      if (!$('#edit-node-submitted', context).is(':checked')) {
        vals.unshift(Drupal.t("Don't display post information"));
      }
      return vals.join(', ');
    });
  }
};

})(jQuery);
;
