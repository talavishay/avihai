Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n!=1)); }, 'strings': {"":{"An AJAX HTTP error occurred.":"\u05ea\u05e7\u05dc\u05ea AJAX HTTP \u05e7\u05e8\u05ea\u05d4.","HTTP Result Code: !status":"\u05e7\u05d5\u05d3 \u05ea\u05d5\u05e6\u05d0\u05ea HTTP: !status","An AJAX HTTP request terminated abnormally.":"\u05d1\u05e7\u05e9\u05ea AJAX HTTP \u05d4\u05d5\u05e4\u05e1\u05e7\u05d4 \u05d1\u05d8\u05e8\u05dd \u05e2\u05ea.","Debugging information follows.":"\u05de\u05d9\u05d3\u05e2 \u05dc\u05e0\u05d9\u05e4\u05d5\u05d9 \u05e9\u05d2\u05d9\u05d0\u05d5\u05ea \u05de\u05d5\u05e6\u05d2 \u05dc\u05d4\u05dc\u05df.","Path: !uri":"\u05e0\u05ea\u05d9\u05d1: !uri","StatusText: !statusText":"\u05d8\u05e7\u05e1\u05d8 \u05e1\u05d8\u05d8\u05d5\u05e1: !statusText","ResponseText: !responseText":"\u05d8\u05e7\u05e1\u05d8 \u05ea\u05d2\u05d5\u05d1\u05d4: !responseText","ReadyState: !readyState":"\u05de\u05e6\u05d1 \u05de\u05d5\u05db\u05e0\u05d5\u05ea: !readyState","@title dialog":"\u05d3\u05d9\u05d0\u05dc\u05d5\u05d2 @title","Configure":"\u05d4\u05d2\u05d3\u05e8","Loading":"\u05d8\u05d5\u05e2\u05df","(active tab)":"(\u05dc\u05e9\u05d5\u05e0\u05d9\u05ea \u05e4\u05e2\u05d9\u05dc\u05d4)","Re-order rows by numerical weight instead of dragging.":"\u05e1\u05d3\u05e8 \u05de\u05d7\u05d3\u05e9 \u05e9\u05d5\u05e8\u05d5\u05ea \u05e2\u05e4\u0022\u05d9 \u05d7\u05e9\u05d9\u05d1\u05d5\u05ea \u05de\u05e1\u05e4\u05e8\u05d9\u05ea \u05d1\u05de\u05e7\u05d5\u05dd \u05d2\u05e8\u05d9\u05e8\u05d4.","Show row weights":"\u05d4\u05e6\u05d2 \u05de\u05e9\u05e7\u05dc\u05d9 \u05e9\u05d5\u05e8\u05d5\u05ea","Hide row weights":"\u05d4\u05e1\u05ea\u05e8 \u05de\u05e9\u05e7\u05dc\u05d9 \u05e9\u05d5\u05e8\u05d5\u05ea","Drag to re-order":"\u05d2\u05e8\u05d5\u05e8 \u05dc\u05e1\u05d9\u05d3\u05d5\u05e8","Changes made in this table will not be saved until the form is submitted.":"\u05e9\u05d9\u05e0\u05d5\u05d9\u05d9\u05dd \u05d1\u05d8\u05d1\u05dc\u05d4 \u05d6\u05d5 \u05dc\u05d0 \u05d9\u05e9\u05de\u05e8\u05d5 \u05e2\u05d3 \u05dc\u05e9\u05dc\u05d9\u05d7\u05ea \u05d4\u05d8\u05d5\u05e4\u05e1.","Hide":"\u05d4\u05e1\u05ea\u05e8\u05d4","Show":"\u05d4\u05e6\u05d2","Disabled":"\u05de\u05d5\u05e9\u05d1\u05ea","Enabled":"\u05de\u05d5\u05e4\u05e2\u05dc","Edit":"\u05e2\u05e8\u05d9\u05db\u05d4","Save":"\u05e9\u05de\u05d9\u05e8\u05d4","Add":"\u05d4\u05d5\u05e1\u05e3","Upload":"\u05d4\u05e2\u05dc\u05d0\u05d4","OK":"OK","Select all rows in this table":"\u05d1\u05d7\u05e8 \u05d0\u05ea \u05db\u05dc \u05d4\u05e9\u05d5\u05e8\u05d5\u05ea \u05d1\u05d8\u05d1\u05dc\u05d4","Deselect all rows in this table":"\u05d1\u05d8\u05dc \u05d1\u05d7\u05d9\u05e8\u05ea \u05db\u05dc \u05d4\u05e9\u05d5\u05e8\u05d5\u05ea \u05d1\u05d8\u05d1\u05dc\u05d4","Not published":"\u05d8\u05e8\u05dd \u05e4\u05d5\u05e8\u05e1\u05dd","Please wait...":"\u05d4\u05de\u05ea\u05df \u05d1\u05d1\u05e7\u05e9\u05d4...","Only files with the following extensions are allowed: %files-allowed.":"\u05e0\u05d9\u05ea\u05df \u05dc\u05d4\u05e9\u05ea\u05de\u05e9 \u05e8\u05e7 \u05d1\u05e7\u05d1\u05e6\u05d9\u05dd \u05d1\u05e2\u05dc\u05d9 \u05d4\u05e1\u05d9\u05d5\u05de\u05d5\u05ea \u05d4\u05d1\u05d0\u05d5\u05ea: %files-allowed.","By @name on @date":"\u05e2\u0022\u05d9 @name \u05d1- @date","By @name":"\u05e2\u0022\u05d9 @name","Not in menu":"\u05dc\u05d0 \u05d1\u05ea\u05e4\u05e8\u05d9\u05d8","No alias":"\u05dc\u05d0 \u05d4\u05d5\u05d2\u05d3\u05e8 \u05de\u05d9\u05e7\u05d5\u05dd \u05d7\u05d9\u05dc\u05d5\u05e4\u05d9","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"\u05d4\u05e9\u05d9\u05e0\u05d5\u05d9\u05d9\u05dd \u05dc\u05d1\u05dc\u05d5\u05e7\u05d9\u05dd \u05d0\u05dc\u05d5 \u05dc\u05d0 \u05d9\u05e9\u05de\u05e8\u05d5 \u05e2\u05d3 \u05dc\u05dc\u05d7\u05d9\u05e6\u05d4 \u05e2\u05dc \u05db\u05e4\u05ea\u05d5\u05e8 \u003Cem\u003E\u05e9\u05de\u05d5\u05e8 \u05d1\u05dc\u05d5\u05e7\u05d9\u05dd\u003C\/em\u003E.","Flag translations as outdated":"\u05e1\u05de\u05df \u05ea\u05e8\u05d2\u05d5\u05de\u05d9\u05dd \u05db\u05dc\u05d0 \u05de\u05e2\u05d5\u05d3\u05db\u05e0\u05d9\u05dd","No revision":"\u05d0\u05d9\u05df \u05d2\u05d9\u05e8\u05e1\u05d4","Requires a title":"\u05d3\u05e8\u05d5\u05e9\u05d4 \u05db\u05d5\u05ea\u05e8\u05ea","Not restricted":"\u05dc\u05d0 \u05de\u05d5\u05d2\u05d1\u05dc","Not customizable":"\u05d0\u05d9\u05e0\u05d5 \u05e0\u05d9\u05ea\u05df \u05dc\u05d4\u05ea\u05d0\u05de\u05d4 \u05d0\u05d9\u05e9\u05d9\u05ea","Restricted to certain pages":"\u05de\u05d5\u05d2\u05d1\u05dc \u05dc\u05d3\u05e4\u05d9\u05dd \u05de\u05e1\u05d5\u05d9\u05d9\u05de\u05d9\u05dd","The block cannot be placed in this region.":"\u05dc\u05d0 \u05e0\u05d9\u05ea\u05df \u05dc\u05de\u05e7\u05dd \u05d0\u05ea \u05d4\u05ea\u05d9\u05d1\u05d4 \u05d1\u05d0\u05d9\u05d6\u05d5\u05e8 \u05d6\u05d4","Hide summary":"\u05d4\u05e1\u05ea\u05e8\u05ea \u05ea\u05e7\u05e6\u05d9\u05e8","Edit summary":"\u05e2\u05e8\u05d9\u05db\u05ea \u05ea\u05e7\u05e6\u05d9\u05e8","Don\u0027t display post information":"\u05dc\u05d0 \u05dc\u05d4\u05e6\u05d9\u05d2 \u05de\u05d9\u05d3\u05e2 \u05e2\u05dc \u05d4\u05e4\u05d5\u05e1\u05d8","Autocomplete popup":"\u05d7\u05dc\u05d5\u05df \u05d4\u05e9\u05dc\u05de\u05d4 \u05d0\u05d5\u05d8\u05d5\u05de\u05d8\u05d9\u05ea \u05e7\u05d5\u05e4\u05e5","Searching for matches...":"\u05de\u05d7\u05e4\u05e9 \u05e2\u05d1\u05d5\u05e8 \u05ea\u05d0\u05d9\u05de\u05d5\u05d9\u05d5\u05ea...","Not translatable":"\u05dc\u05d0 \u05e0\u05d9\u05ea\u05df \u05dc\u05ea\u05e8\u05d2\u05d5\u05dd"}} };;
(function () {
Drupal.behaviors.avihai = {
	attach: function (context, settings) {
		var menu_target = null,title = jQuery("#edit-title-field input");
		
			if(jQuery("form.node-form [name=changed]").val() !== ""){
				title.attr("data-original-title", function(v,a){return this.value});
				jQuery("#multiple-node-menu-wrapper input.form-text").each(function(i, val){
					if(jQuery(val).val() === title.attr("data-original-title") ){
						jQuery(val).attr("data-target",1);
						menu_target = val;
					}
				});
			}
			title.bind("change blur keyup", function(e){
				if(window.location.toString().match(/edit/) === null || window.location.toString().match(/edit(.*)add/) !== null){
					jQuery("#edit-menu-link-title,#edit-multiple-node-menu-add-link-link-title").val(jQuery(e.currentTarget).val());
				}else{
					jQuery(menu_target).val(jQuery(e.currentTarget).val());
				}
			});
			
			jQuery("#edit-multiple-node-menu-enabled:not(:checked)").click();

			}
}
})();

jQuery(document).ready(function () { 
	Drupal.behaviors.avihai.attach();
	var t1 = window.setTimeout(function(){
		if(jQuery("body").hasClass("admin-menu")){		
			jQuery("#admin-menu [href*=\\/block\\/add]").attr("href",'/'+Drupal.settings.pathPrefix+"node/add/media-block"); 
		}
	},1000);
});
;
